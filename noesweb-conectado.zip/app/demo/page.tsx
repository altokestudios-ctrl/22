import type { Metadata } from 'next'
import Link from 'next/link'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'
import { DemoShowcase } from '@/components/demo-showcase'
import { whatsappLink } from '@/lib/site'

export const metadata: Metadata = {
  title: 'Demostración en vivo | Altoke Studio',
  description: 'Mirá cómo el Sistema Automático de Altoke Studio atiende, cotiza y cierra ventas por WhatsApp.',
}

export default function DemoPage() {
  return (
    <>
      <header className="border-b border-border/70 bg-background">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6">
          <Link href="/" aria-label="Altoke Studio, volver al inicio">
            <BrandLogo />
          </Link>
          <Link
            href="/"
            className="inline-flex min-h-11 items-center gap-2 rounded-xl px-3 text-sm font-medium text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
          >
            <ArrowLeft className="size-4" aria-hidden="true" />
            Volver al inicio
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24 pt-12 sm:px-6 lg:pt-16">
        <div className="max-w-2xl">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Demostración en vivo</p>
          <h1 className="mt-3 text-balance text-4xl font-extrabold tracking-tight sm:text-5xl">
            Así trabaja el Sistema Automático
          </h1>
          <p className="mt-4 text-pretty text-lg leading-relaxed text-muted-foreground">
            Elegí una situación real y mirá cómo el asistente responde en segundos, consulta tus datos y lleva al cliente
            hasta la compra.
          </p>
        </div>

        <div className="mt-12">
          <DemoShowcase />
        </div>

        <section className="mt-20 flex flex-col items-start justify-between gap-6 rounded-2xl bg-foreground p-8 text-background sm:flex-row sm:items-center">
          <div>
            <h2 className="font-heading text-2xl font-bold">¿Lo querés para tu negocio?</h2>
            <p className="mt-1 text-background/70">Lo entrenamos con tus productos, precios y forma de atender.</p>
          </div>
          <div className="flex flex-col gap-3 sm:flex-row">
            <Link
              href="/#planes"
              className="inline-flex min-h-11 items-center justify-center rounded-xl border border-background/20 px-5 py-3 text-sm font-semibold transition-colors hover:bg-background/10"
            >
              Ver planes
            </Link>
            <a
              href={whatsappLink('Hola! Vi la demo y quiero el Sistema Automático para mi negocio.')}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              Hablar por WhatsApp
              <ArrowRight className="size-4" aria-hidden="true" />
            </a>
          </div>
        </section>
      </main>
    </>
  )
}
