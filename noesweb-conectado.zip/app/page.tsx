import { SiteHeader } from '@/components/site-header'
import { Hero } from '@/components/hero'
import { Metrics } from '@/components/metrics'
import { ProcessSteps } from '@/components/process-steps'
import { ProblemSolution } from '@/components/problem-solution'
import { Services } from '@/components/services'
import { Testimonial } from '@/components/testimonial'
import { CtaBand } from '@/components/cta-band'
import { Pricing } from '@/components/pricing'
import { Faq } from '@/components/faq'
import { SiteFooter } from '@/components/site-footer'
import { WhatsappFloat } from '@/components/whatsapp-float'
import { LeadFormProvider } from '@/components/lead-form-provider'

export default function Page() {
  return (
    <LeadFormProvider>
      <SiteHeader />
      <main>
        <Hero />
        <Metrics />
        <ProcessSteps />
        <ProblemSolution />
        <Services />
        <Testimonial />
        <CtaBand />
        <Pricing />
        <Faq />
      </main>
      <SiteFooter />
      <WhatsappFloat />
    </LeadFormProvider>
  )
}
