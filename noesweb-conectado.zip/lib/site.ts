export const WHATSAPP_NUMBER = '5493462538454'

export function whatsappLink(message = 'Hola! Quiero automatizar las ventas de mi negocio.') {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`
}

export const navLinks = [
  { href: '#servicios', label: 'Servicios' },
  { href: '#como-funciona', label: 'Cómo funciona' },
  { href: '#planes', label: 'Planes' },
  { href: '#faq', label: 'Preguntas frecuentes' },
]
