'use client'

import { useEffect, useRef, useState } from 'react'
import { ArrowLeft, CheckCheck, CreditCard, MoreVertical, Phone, RotateCcw, Video } from 'lucide-react'
import { cn } from '@/lib/utils'

export type Message = {
  from: 'client' | 'bot'
  time: string
  content: React.ReactNode
}

const defaultScript: Message[] = [
  {
    from: 'client',
    time: '23:47',
    content: 'Hola, ¿tienen stock del compresor de 1/4 para heladera comercial?',
  },
  {
    from: 'bot',
    time: '23:47',
    content: (
      <>
        ¡Hola! Sí, tenemos <strong>4 unidades en stock</strong> del Compresor 1/4 HP (gas R134a) para heladera comercial.
      </>
    ),
  },
  {
    from: 'bot',
    time: '23:47',
    content: (
      <>
        <span className="block font-semibold">Precio: $185.900</span>
        <span className="block">3 cuotas sin interés · Envío en el día.</span>
      </>
    ),
  },
  {
    from: 'client',
    time: '23:48',
    content: 'Perfecto, lo quiero. ¿Cómo pago?',
  },
  {
    from: 'bot',
    time: '23:48',
    content: (
      <>
        ¡Genial! Te reservé una unidad. Podés pagar acá:
        <span className="mt-2 flex items-center gap-2 rounded-lg bg-background/70 p-2 text-xs font-semibold text-accent-foreground">
          <CreditCard className="size-4 shrink-0" aria-hidden="true" />
          <span className="underline underline-offset-2">mpago.la/compresor-14hp</span>
        </span>
      </>
    ),
  },
]

const defaultDelays = [600, 1500, 1300, 1700, 1500]

type WhatsappDemoProps = {
  className?: string
  script?: Message[]
  delays?: number[]
  contactName?: string
  contactInitials?: string
  dayLabel?: string
}

export function WhatsappDemo({
  className,
  script = defaultScript,
  delays = defaultDelays,
  contactName = 'Refrigeración del Sur',
  contactInitials = 'RF',
  dayLabel = 'Sábado',
}: WhatsappDemoProps) {
  const [visible, setVisible] = useState(0)
  const [typing, setTyping] = useState(false)
  const [run, setRun] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    if (reduceMotion) {
      setVisible(script.length)
      return
    }
    setVisible(0)
    const timers: ReturnType<typeof setTimeout>[] = []
    let elapsed = 0
    script.forEach((msg, i) => {
      elapsed += delays[i] ?? 1500
      if (msg.from === 'bot') {
        timers.push(setTimeout(() => setTyping(true), elapsed - 900))
      }
      timers.push(
        setTimeout(() => {
          setTyping(false)
          setVisible(i + 1)
        }, elapsed),
      )
    })
    return () => timers.forEach(clearTimeout)
  }, [run, script, delays])

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [visible, typing])

  const finished = visible === script.length

  return (
    <div className={cn('relative mx-auto w-full max-w-[320px]', className)}>
      <div className="animate-float rounded-[2.75rem] border-[10px] border-foreground bg-foreground shadow-2xl shadow-foreground/20">
        <div className="overflow-hidden rounded-[2rem] bg-chat">
          <div className="flex items-center gap-3 bg-chat-header px-4 pb-3 pt-5 text-white">
            <ArrowLeft className="size-4 opacity-80" aria-hidden="true" />
            <div className="flex size-9 items-center justify-center rounded-full bg-white/20 text-sm font-bold">{contactInitials}</div>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold">{contactName}</p>
              <p className="text-[11px] opacity-80">{typing ? 'escribiendo…' : 'en línea'}</p>
            </div>
            <Video className="size-4 opacity-80" aria-hidden="true" />
            <Phone className="size-4 opacity-80" aria-hidden="true" />
            <MoreVertical className="size-4 opacity-80" aria-hidden="true" />
          </div>

          <div
            ref={scrollRef}
            role="log"
            aria-live="polite"
            aria-label="Conversación de ejemplo por WhatsApp"
            className="flex h-[460px] flex-col gap-2 overflow-y-auto px-3 py-4"
          >
            <p className="mx-auto mb-1 rounded-md bg-white/80 px-2 py-0.5 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
              {dayLabel}
            </p>
            {script.slice(0, visible).map((msg, i) => (
              <div
                key={`${run}-${i}`}
                className={cn(
                  'max-w-[85%] animate-in fade-in slide-in-from-bottom-2 rounded-xl px-3 py-2 text-[13px] leading-snug text-foreground shadow-sm duration-300',
                  msg.from === 'client' ? 'self-end rounded-tr-sm bg-chat-bubble' : 'self-start rounded-tl-sm bg-white',
                )}
              >
                {msg.content}
                <span className="mt-1 flex items-center justify-end gap-1 text-[10px] text-muted-foreground">
                  {msg.time}
                  {msg.from === 'client' && <CheckCheck className="size-3 text-sky-500" aria-hidden="true" />}
                </span>
              </div>
            ))}
            {typing && (
              <div className="flex gap-1 self-start rounded-xl rounded-tl-sm bg-white px-3 py-3 shadow-sm" aria-hidden="true">
                <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.3s]" />
                <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground [animation-delay:-0.15s]" />
                <span className="size-1.5 animate-bounce rounded-full bg-muted-foreground" />
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="absolute -left-10 -top-5 z-10 hidden rounded-xl border border-border bg-card px-3 py-2 shadow-lg sm:block">
        <p className="text-[11px] text-muted-foreground">Tiempo de respuesta</p>
        <p className="font-heading text-sm font-bold text-primary">2 segundos</p>
      </div>

      <div className="mt-4 flex justify-center">
        <button
          type="button"
          onClick={() => setRun((r) => r + 1)}
          disabled={!finished}
          className="inline-flex items-center gap-1.5 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground disabled:opacity-50"
        >
          <RotateCcw className="size-3.5" aria-hidden="true" />
          Repetir demostración
        </button>
      </div>
    </div>
  )
}
