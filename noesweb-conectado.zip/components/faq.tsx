import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Reveal } from '@/components/reveal'

const faqs = [
  {
    q: '¿Necesito conocimientos técnicos?',
    a: 'Para nada. Nosotros nos encargamos de absolutamente todo. Vos solo nos pasás tu catálogo y te hacemos unas preguntas sobre tu negocio. En 48 horas tenés tu asistente andando.',
  },
  {
    q: '¿Funciona con mi número de WhatsApp actual?',
    a: 'Sí. Conectamos el bot a tu WhatsApp Business sin cambiar tu número. Tus clientes ni se enteran del cambio.',
  },
  {
    q: '¿Qué pasa si el bot no sabe responder algo?',
    a: 'El bot escala automáticamente la conversación a vos o a tu equipo, con todo el contexto previo de la charla. Nunca deja al cliente sin respuesta.',
  },
  {
    q: '¿Cuánto tarda la implementación?',
    a: 'Entre 24 y 72 horas hábiles, dependiendo de la complejidad de tu catálogo y las integraciones que necesites.',
  },
  {
    q: '¿Puedo cancelar cuando quiera?',
    a: 'Sí. No hay contratos de permanencia. Cancelás el abono mensual cuando quieras, sin penalidades.',
  },
  {
    q: '¿Qué medios de pago aceptan?',
    a: 'Mercado Pago (tarjeta, QR o link de pago), transferencia bancaria y efectivo.',
  },
]

export function Faq() {
  return (
    <section id="faq" aria-labelledby="faq-title" className="scroll-mt-16 border-t border-border bg-card py-20 lg:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <Reveal className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Preguntas frecuentes</p>
          <h2 id="faq-title" className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            ¿Tenés dudas? Acá las resolvemos
          </h2>
        </Reveal>

        <Reveal className="mt-12">
          <Accordion className="gap-3">
            {faqs.map((item) => (
              <AccordionItem
                key={item.q}
                value={item.q}
                className="rounded-2xl border border-border bg-background px-5 transition-shadow not-last:border-b hover:shadow-sm"
              >
                <AccordionTrigger className="py-5 text-base font-semibold hover:no-underline">{item.q}</AccordionTrigger>
                <AccordionContent className="pb-5 text-base leading-relaxed text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  )
}
