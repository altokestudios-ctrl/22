import { Reveal } from '@/components/reveal'

const metrics = [
  { value: '2 seg', label: 'Tiempo promedio de respuesta' },
  { value: '+5.000', label: 'Conversaciones automatizadas/mes' },
  { value: '24/7', label: 'Disponibilidad total, feriados incluidos' },
  { value: '97%', label: 'Satisfacción de clientes' },
]

export function Metrics() {
  return (
    <section aria-labelledby="metricas" className="px-4 sm:px-6">
      <Reveal className="mx-auto max-w-6xl rounded-3xl bg-foreground px-6 py-14 text-background sm:px-10">
        <h2 id="metricas" className="sr-only">
          Resultados en números
        </h2>
        <dl className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {metrics.map((m) => (
            <div
              key={m.label}
              className="flex flex-col-reverse gap-1 rounded-2xl border border-background/10 bg-background/5 p-5"
            >
              <dt className="text-xs leading-relaxed text-background/60 sm:text-sm">{m.label}</dt>
              <dd className="font-heading text-2xl font-bold text-primary sm:text-3xl">{m.value}</dd>
            </div>
          ))}
        </dl>
      </Reveal>
    </section>
  )
}
