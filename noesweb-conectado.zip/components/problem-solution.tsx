import { Clock, Database, PiggyBank, CalendarX, UserX, Hourglass } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const problems = [
  {
    icon: CalendarX,
    title: 'Mensajes acumulados el fin de semana',
    text: 'El lunes abrís WhatsApp y tenés 40 chats sin leer. La mitad ya compró en otro lado.',
  },
  {
    icon: UserX,
    title: 'Clientes que se van a la competencia',
    text: 'Si no respondés en minutos, el cliente le escribe al siguiente de la lista de Google.',
  },
  {
    icon: Hourglass,
    title: 'Horas respondiendo lo mismo',
    text: '"¿Tenés stock?", "¿Cuánto sale?", "¿Hacen envíos?". Todo el día, todos los días.',
  },
]

const solutions = [
  {
    icon: Clock,
    title: 'Atención inmediata',
    text: 'Tus clientes no esperan. La IA responde en 2 segundos, de día, de noche y en feriados.',
  },
  {
    icon: Database,
    title: 'Conectado a tu stock',
    text: 'El bot lee tu inventario en tiempo real desde una simple planilla. Nunca vende lo que no tenés.',
  },
  {
    icon: PiggyBank,
    title: 'Costos operativos mínimos',
    text: 'Sin plataformas costosas en dólares. Usamos arquitectura propia para que el margen quede en tu bolsillo.',
  },
]

export function ProblemSolution() {
  return (
    <section id="como-funciona" className="scroll-mt-16 border-y border-border bg-card py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Cómo funciona</p>
          <h2 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            ¿Por qué los negocios locales eligen nuestra infraestructura?
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Sabemos cómo es atender un negocio en Argentina. Por eso armamos un sistema que trabaja cuando vos no podés.
          </p>
        </Reveal>

        <div className="mt-14 grid gap-8 lg:grid-cols-2">
          <Reveal className="rounded-2xl bg-muted/60 p-6 sm:p-8">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-muted-foreground">Hoy, sin automatizar</h3>
            <ul className="mt-6 flex flex-col gap-4">
              {problems.map(({ icon: Icon, title, text }) => (
                <li key={title} className="flex gap-4 rounded-xl border border-border bg-card p-5">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-destructive/10 text-destructive">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="font-semibold">{title}</p>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={120} className="rounded-2xl border border-primary/20 bg-accent p-6 sm:p-8">
            <h3 className="text-sm font-semibold uppercase tracking-wider text-accent-foreground">
              Con Altoke Studio
            </h3>
            <ul className="mt-6 flex flex-col gap-4">
              {solutions.map(({ icon: Icon, title, text }) => (
                <li key={title} className="flex gap-4 rounded-xl bg-card p-5 shadow-sm">
                  <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary text-primary-foreground">
                    <Icon className="size-5" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="font-semibold">{title}</p>
                    <p className="mt-1 text-sm leading-relaxed text-muted-foreground">{text}</p>
                  </div>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>
      </div>
    </section>
  )
}
