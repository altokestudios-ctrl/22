import { MessageCircle } from 'lucide-react'
import { Reveal } from '@/components/reveal'
import { whatsappLink } from '@/lib/site'

export function CtaBand() {
  return (
    <section aria-labelledby="cta-intermedio" className="px-4 sm:px-6">
      <Reveal className="mx-auto flex max-w-6xl flex-col items-start justify-between gap-8 rounded-3xl border border-primary/20 bg-[linear-gradient(120deg,var(--color-accent)_0%,var(--color-card)_100%)] p-8 sm:p-10 md:flex-row md:items-center">
        <div>
          <h2 id="cta-intermedio" className="text-balance text-2xl font-bold sm:text-3xl">
            ¿Querés resultados como estos en tu negocio?
          </h2>
          <p className="mt-2 text-pretty text-muted-foreground">
            Mirá cómo respondería el bot a tus propios clientes, con tu catálogo y tus precios.
          </p>
        </div>
        <div className="flex shrink-0 flex-col items-start gap-2 md:items-center">
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:scale-[1.02] hover:bg-primary/90"
          >
            <MessageCircle className="size-5" aria-hidden="true" />
            Quiero automatizar mis ventas
          </a>
          <p className="text-xs text-muted-foreground">Sin compromiso. Sin tarjeta de crédito.</p>
        </div>
      </Reveal>
    </section>
  )
}
