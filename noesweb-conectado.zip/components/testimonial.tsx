import { Star } from 'lucide-react'
import { Reveal } from '@/components/reveal'

const stats = [
  { value: '24/7', label: 'Atención sin pausa' },
  { value: '2 seg', label: 'Tiempo de respuesta' },
  { value: '+40%', label: 'Consultas convertidas' },
]

const testimonials = [
  {
    quote: 'Lo mejor es que labura los domingos. Mis clientes consultan el fin de semana y el lunes ya tengo los pedidos armados.',
    name: 'Laura S.',
    role: 'Distribuidora de insumos, Córdoba',
    initials: 'LS',
  },
  {
    quote: 'Pensé que iba a ser complicado. En 2 días ya estaba andando y mis clientes ni notan que es un bot.',
    name: 'Diego R.',
    role: 'Ferretería Industrial, Rosario',
    initials: 'DR',
  },
]

function Stars({ className = 'size-5' }: { className?: string }) {
  return (
    <div className="flex gap-1" role="img" aria-label="5 de 5 estrellas">
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={`${className} fill-star text-star`} aria-hidden="true" />
      ))}
    </div>
  )
}

export function Testimonial() {
  return (
    <section aria-labelledby="testimonios" className="py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Testimonios</p>
          <h2 id="testimonios" className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Lo que dicen nuestros clientes
          </h2>
        </Reveal>

        <Reveal className="mt-14 overflow-hidden rounded-3xl bg-foreground px-6 py-12 text-background sm:px-12 lg:py-16">
          <div className="grid items-center gap-12 lg:grid-cols-[1.4fr_1fr]">
            <figure>
              <Stars />
              <blockquote className="mt-6 text-pretty font-heading text-2xl font-semibold leading-snug sm:text-3xl">
                {
                  '"Antes perdíamos horas respondiendo si teníamos repuestos. Ahora el bot califica al cliente, revisa el stock y nos pasa el pedido listo para despachar."'
                }
              </blockquote>
              <figcaption className="mt-6 flex items-center gap-3">
                <span className="flex size-11 items-center justify-center rounded-full bg-primary font-bold text-primary-foreground">
                  MG
                </span>
                <span>
                  <span className="block font-semibold">Martín G.</span>
                  <span className="block text-sm text-background/60">Casa de repuestos de refrigeración, GBA</span>
                </span>
              </figcaption>
            </figure>

            <dl className="grid grid-cols-3 gap-4 lg:grid-cols-1">
              {stats.map((s) => (
                <div key={s.label} className="flex flex-col-reverse rounded-2xl border border-background/10 bg-background/5 p-4 sm:p-5">
                  <dt className="text-xs text-background/60 sm:text-sm">{s.label}</dt>
                  <dd className="font-heading text-2xl font-bold text-primary sm:text-3xl">{s.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </Reveal>

        <div className="mt-6 grid gap-6 md:grid-cols-2">
          {testimonials.map((t, i) => (
            <Reveal key={t.name} delay={i * 120} className="h-full">
              <figure className="flex h-full flex-col rounded-2xl border border-border bg-card p-7 shadow-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
                <Stars className="size-4" />
                <blockquote className="mt-4 flex-1 text-pretty text-lg leading-relaxed">{`"${t.quote}"`}</blockquote>
                <figcaption className="mt-6 flex items-center gap-3">
                  <span className="flex size-10 items-center justify-center rounded-full bg-primary text-sm font-bold text-primary-foreground">
                    {t.initials}
                  </span>
                  <span>
                    <span className="block font-semibold">{t.name}</span>
                    <span className="block text-sm text-muted-foreground">{t.role}</span>
                  </span>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
