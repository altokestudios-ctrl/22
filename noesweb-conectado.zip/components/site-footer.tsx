import { Mail, MapPin, MessageCircle } from 'lucide-react'
import { BrandLogo } from '@/components/brand-logo'
import { navLinks, whatsappLink } from '@/lib/site'

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-card">
      <div className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="flex flex-col items-start justify-between gap-8 rounded-3xl bg-accent p-8 sm:p-10 md:flex-row md:items-center">
          <div>
            <h2 className="text-balance text-2xl font-bold sm:text-3xl">¿Arrancamos a automatizar tu negocio?</h2>
            <p className="mt-2 text-muted-foreground">Escribinos y en 15 minutos te mostramos cómo funcionaría en tu rubro.</p>
          </div>
          <a
            href={whatsappLink()}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex shrink-0 items-center gap-2 rounded-xl bg-primary px-6 py-3.5 font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-colors hover:bg-primary/90"
          >
            <MessageCircle className="size-5" aria-hidden="true" />
            Quiero automatizar mis ventas
          </a>
        </div>

        <div className="mt-14 grid gap-10 sm:grid-cols-3">
          <div>
            <BrandLogo />
            <p className="mt-3 max-w-xs text-sm leading-relaxed text-muted-foreground">
              Sistemas de venta automatizada con IA para Pymes argentinas.
            </p>
            <ul className="mt-4 flex gap-2">
              <li>
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex size-9 items-center justify-center rounded-lg border border-border text-muted-foreground transition-colors hover:text-foreground"
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4" aria-hidden="true">
                    <rect x="2" y="2" width="20" height="20" rx="5" />
                    <circle cx="12" cy="12" r="4" />
                    <circle cx="17.5" cy="6.5" r="0.5" fill="currentColor" />
                  </svg>
                  <span className="sr-only">Instagram</span>
                </a>
              </li>
              <li>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex size-9 items-center justify-center rounded-lg border border-border text-muted-foreground transition-colors hover:text-foreground"
                >
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="size-4" aria-hidden="true">
                    <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-4 0v7h-4v-7a6 6 0 0 1 6-6z" />
                    <rect x="2" y="9" width="4" height="12" />
                    <circle cx="4" cy="4" r="2" />
                  </svg>
                  <span className="sr-only">LinkedIn</span>
                </a>
              </li>
            </ul>
          </div>
          <nav aria-label="Pie de página">
            <p className="text-sm font-semibold">Navegación</p>
            <ul className="mt-3 flex flex-col gap-2">
              {navLinks.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-sm text-muted-foreground hover:text-foreground">
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
          <div>
            <p className="text-sm font-semibold">Contacto</p>
            <ul className="mt-3 flex flex-col gap-2 text-sm text-muted-foreground">
              <li>
                <a href={whatsappLink()} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 hover:text-foreground">
                  <MessageCircle className="size-4" aria-hidden="true" />
                  WhatsApp
                </a>
              </li>
              <li>
                <a href="mailto:hola@sistemasautomaticos.com.ar" className="flex items-center gap-2 hover:text-foreground">
                  <Mail className="size-4" aria-hidden="true" />
                  hola@sistemasautomaticos.com.ar
                </a>
              </li>
              <li className="flex items-center gap-2">
                <MapPin className="size-4" aria-hidden="true" />
                Buenos Aires, Argentina
              </li>
            </ul>
          </div>
        </div>

        <p className="mt-12 border-t border-border pt-6 text-xs text-muted-foreground">
          © 2026 Altoke Studio. Todos los derechos reservados.
        </p>
      </div>
    </footer>
  )
}
