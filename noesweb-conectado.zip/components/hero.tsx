import { ArrowRight, Check, PlayCircle } from 'lucide-react'
import { WhatsappDemo } from '@/components/whatsapp-demo'
import Link from 'next/link'
import { LeadFormTrigger } from '@/components/lead-form-provider'

const highlights = ['Responde en 2 segundos', 'Conectado a tu stock', 'Sin contratos eternos']

export function Hero() {
  return (
    <section id="inicio" className="relative overflow-hidden pt-28 pb-20 sm:pt-32 lg:pb-28">
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-x-0 top-0 -z-10 h-[560px] bg-[radial-gradient(60%_60%_at_70%_20%,var(--color-accent)_0%,transparent_70%)]"
      />
      <div className="mx-auto grid max-w-6xl items-center gap-14 px-4 sm:px-6 lg:grid-cols-[1.15fr_1fr]">
        <div>
          <p className="inline-flex items-center gap-2 rounded-full border border-emerald-200 bg-emerald-50 px-3 py-1 text-xs font-semibold text-emerald-700">
            <span className="relative flex size-2" aria-hidden="true">
              <span className="absolute inline-flex size-full animate-ping rounded-full bg-emerald-500/60 motion-reduce:hidden" />
              <span className="relative inline-flex size-2 rounded-full bg-emerald-500" />
            </span>
            +150 negocios ya automatizaron sus ventas
          </p>
          <h1 className="mt-6 text-balance text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
            No pierdas más ventas por tardar en responder <span className="text-primary">WhatsApp.</span>
          </h1>
          <p className="mt-6 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
            Sistemas de Inteligencia Artificial que atienden a tus clientes, consultan tu stock, cotizan y cierran ventas
            las 24 horas. Diseñado para la realidad de los negocios locales.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link
              href="/demo"
              className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-primary px-5 py-3.5 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-colors hover:bg-primary/90"
            >
              <PlayCircle className="size-5" aria-hidden="true" />
              Ver demostración en vivo
            </Link>
            <LeadFormTrigger
              plan="No estoy seguro, necesito asesoramiento"
              origen="hero"
              className="inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-xl border border-border bg-card px-5 py-3.5 text-base font-semibold shadow-sm transition-colors hover:bg-muted"
            >
              Quiero automatizar mis ventas
              <ArrowRight className="size-4" aria-hidden="true" />
            </LeadFormTrigger>
          </div>

          <ul className="mt-8 flex flex-wrap gap-x-6 gap-y-2">
            {highlights.map((item) => (
              <li key={item} className="flex items-center gap-2 text-sm font-medium text-muted-foreground">
                <Check className="size-4 text-primary" aria-hidden="true" />
                {item}
              </li>
            ))}
          </ul>
        </div>

        <div id="demo" className="scroll-mt-24">
          <WhatsappDemo />
        </div>
      </div>
    </section>
  )
}
