export const LEAD_PLANS = ['Plan Inicio', 'Plan Crecimiento', 'No estoy seguro, necesito asesoramiento'] as const
export type LeadPlan = (typeof LEAD_PLANS)[number]

export const LEAD_ORIGENES = ['hero', 'plan-inicio', 'plan-crecimiento'] as const
export type LeadOrigen = (typeof LEAD_ORIGENES)[number]
