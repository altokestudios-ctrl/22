import { NextResponse } from 'next/server'
import { z } from 'zod'
import { LEAD_ORIGENES, LEAD_PLANS } from '@/lib/lead'

export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'

const MAX_BODY_BYTES = 10_000
const WEBHOOK_TIMEOUT_MS = 10_000
const RATE_WINDOW_MS = 10 * 60 * 1000
const RATE_MAX_REQUESTS = 5

const leadSchema = z.object({
  nombre: z.string().trim().min(2).max(120),
  negocio: z.string().trim().min(2).max(160),
  telefono: z.string().regex(/^\+54\d{10}$/),
  plan: z.enum(LEAD_PLANS),
  mensaje: z.string().trim().max(1000),
  origen: z.enum(LEAD_ORIGENES),
  website: z.string().max(200).optional(),
})

// Límite por IP en memoria. En Vercel cada instancia tiene su propia memoria,
// así que reduce el abuso casual pero no reemplaza a un límite compartido (Upstash, Vercel Firewall).
const hits = new Map<string, number[]>()

function isRateLimited(ip: string) {
  const now = Date.now()
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < RATE_WINDOW_MS)
  recent.push(now)
  hits.set(ip, recent)

  if (hits.size > 5000) {
    for (const [key, times] of hits) {
      if (times.every((t) => now - t >= RATE_WINDOW_MS)) hits.delete(key)
    }
  }
  return recent.length > RATE_MAX_REQUESTS
}

function clientIp(request: Request) {
  const forwarded = request.headers.get('x-forwarded-for')
  return forwarded?.split(',')[0]?.trim() || request.headers.get('x-real-ip') || 'unknown'
}

export async function POST(request: Request) {
  if (isRateLimited(clientIp(request))) {
    return NextResponse.json({ ok: false, error: 'rate_limited' }, { status: 429 })
  }

  const raw = await request.text()
  if (raw.length > MAX_BODY_BYTES) {
    return NextResponse.json({ ok: false, error: 'payload_too_large' }, { status: 413 })
  }

  let json: unknown
  try {
    json = JSON.parse(raw)
  } catch {
    return NextResponse.json({ ok: false, error: 'invalid_json' }, { status: 400 })
  }

  const parsed = leadSchema.safeParse(json)
  if (!parsed.success) {
    return NextResponse.json({ ok: false, error: 'invalid_data' }, { status: 400 })
  }

  const { website, ...lead } = parsed.data

  // Honeypot: un bot completó el campo oculto. Respondemos OK sin enviar nada.
  if (website) {
    return NextResponse.json({ ok: true })
  }

  const webhookUrl = process.env.N8N_WEBHOOK_URL
  if (!webhookUrl) {
    console.error('[api/lead] Falta la variable de entorno N8N_WEBHOOK_URL')
    return NextResponse.json({ ok: false, error: 'server_misconfigured' }, { status: 500 })
  }

  const controller = new AbortController()
  const timer = setTimeout(() => controller.abort(), WEBHOOK_TIMEOUT_MS)

  try {
    const response = await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(lead),
      cache: 'no-store',
      signal: controller.signal,
    })

    if (!response.ok) {
      console.error('[api/lead] n8n respondió con estado', response.status)
      return NextResponse.json({ ok: false, error: 'upstream_error' }, { status: 502 })
    }

    return NextResponse.json({ ok: true })
  } catch (error) {
    console.error('[api/lead] No se pudo contactar a n8n', error)
    return NextResponse.json({ ok: false, error: 'upstream_unreachable' }, { status: 502 })
  } finally {
    clearTimeout(timer)
  }
}
