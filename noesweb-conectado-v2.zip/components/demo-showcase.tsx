'use client'

import { useState } from 'react'
import { CalendarCheck, CreditCard, PackageSearch, Zap } from 'lucide-react'
import { WhatsappDemo, type Message } from '@/components/whatsapp-demo'
import { cn } from '@/lib/utils'

type Scenario = {
  id: string
  label: string
  icon: typeof Zap
  business: string
  initials: string
  day: string
  steps: string[]
  script: Message[]
}

const scenarios: Scenario[] = [
  {
    id: 'stock',
    label: 'Consulta de stock',
    icon: PackageSearch,
    business: 'Refrigeración del Sur',
    initials: 'RF',
    day: 'Sábado',
    steps: [
      'Detecta el producto que busca el cliente',
      'Consulta el stock y el precio en el catálogo del negocio',
      'Ofrece cuotas y envío según tus reglas',
      'Genera el link de pago y reserva la unidad',
    ],
    script: [
      { from: 'client', time: '23:47', content: 'Hola, ¿tienen stock del compresor de 1/4 para heladera comercial?' },
      {
        from: 'bot',
        time: '23:47',
        content: (
          <>
            ¡Hola! Sí, tenemos <strong>4 unidades en stock</strong> del Compresor 1/4 HP (gas R134a).
          </>
        ),
      },
      {
        from: 'bot',
        time: '23:47',
        content: (
          <>
            <span className="block font-semibold">Precio: $185.900</span>
            <span className="block">3 cuotas sin interés · Envío en el día.</span>
          </>
        ),
      },
      { from: 'client', time: '23:48', content: 'Perfecto, lo quiero. ¿Cómo pago?' },
      {
        from: 'bot',
        time: '23:48',
        content: (
          <>
            ¡Genial! Te reservé una unidad. Podés pagar acá:
            <span className="mt-2 flex items-center gap-2 rounded-lg bg-background/70 p-2 text-xs font-semibold text-accent-foreground">
              <CreditCard className="size-4 shrink-0" aria-hidden="true" />
              <span className="underline underline-offset-2">mpago.la/compresor-14hp</span>
            </span>
          </>
        ),
      },
    ],
  },
  {
    id: 'cotizacion',
    label: 'Cotización mayorista',
    icon: Zap,
    business: 'Distribuidora Norte',
    initials: 'DN',
    day: 'Hoy',
    steps: [
      'Entiende cantidades y productos en lenguaje natural',
      'Aplica tu lista de precios mayorista',
      'Arma el presupuesto con descuento por volumen',
      'Deriva a un vendedor cuando hace falta cerrar',
    ],
    script: [
      { from: 'client', time: '10:12', content: 'Buenas! Necesito precio por 20 cajas de lavandina 5L y 10 de detergente.' },
      { from: 'bot', time: '10:12', content: '¡Hola! Ya te armo el presupuesto con lista mayorista.' },
      {
        from: 'bot',
        time: '10:12',
        content: (
          <>
            <span className="block">20 × Lavandina 5L — $4.300 c/u</span>
            <span className="block">10 × Detergente 5L — $6.900 c/u</span>
            <span className="mt-1 block font-semibold">Total con 8% off: $142.600</span>
          </>
        ),
      },
      { from: 'client', time: '10:13', content: '¿Me lo pueden mandar a Rosario el jueves?' },
      {
        from: 'bot',
        time: '10:13',
        content: 'Sí, el jueves tenemos reparto en Rosario. Te paso con Martín para confirmar la dirección y la factura.',
      },
    ],
  },
  {
    id: 'turnos',
    label: 'Turnos fuera de horario',
    icon: CalendarCheck,
    business: 'Taller Mecánico Gómez',
    initials: 'TG',
    day: 'Domingo',
    steps: [
      'Atiende aunque tu negocio esté cerrado',
      'Revisa tu agenda y propone horarios libres',
      'Confirma el turno y guarda los datos del cliente',
      'Envía un recordatorio automático el día anterior',
    ],
    script: [
      { from: 'client', time: '21:30', content: 'Hola, ¿me dan un turno para service del auto esta semana?' },
      { from: 'bot', time: '21:30', content: '¡Hola! Claro. ¿Qué auto tenés y cuántos km aproximados?' },
      { from: 'client', time: '21:31', content: 'Un Gol Trend 2017, 80.000 km.' },
      {
        from: 'bot',
        time: '21:31',
        content: (
          <>
            Perfecto, service de 80.000 km: <strong>$95.000</strong>. Tengo libre el <strong>martes 9:00</strong> o el{' '}
            <strong>miércoles 14:30</strong>. ¿Cuál preferís?
          </>
        ),
      },
      { from: 'client', time: '21:32', content: 'Martes 9 está bien.' },
      {
        from: 'bot',
        time: '21:32',
        content: '¡Listo! Turno confirmado para el martes 9:00. Te mando un recordatorio el lunes.',
      },
    ],
  },
]

export function DemoShowcase() {
  const [activeId, setActiveId] = useState(scenarios[0].id)
  const active = scenarios.find((s) => s.id === activeId) ?? scenarios[0]

  return (
    <div className="grid items-start gap-12 lg:grid-cols-[1fr_auto]">
      <div>
        <p className="text-sm font-semibold uppercase tracking-wider text-primary">Elegí un escenario</p>
        <div role="group" aria-label="Escenarios de demostración" className="mt-4 flex flex-wrap gap-2">
          {scenarios.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              type="button"
              aria-pressed={id === activeId}
              onClick={() => setActiveId(id)}
              className={cn(
                'inline-flex min-h-11 items-center gap-2 rounded-xl border px-4 py-2 text-sm font-semibold transition-colors',
                id === activeId
                  ? 'border-primary bg-primary text-primary-foreground shadow-sm'
                  : 'border-border bg-card text-foreground hover:bg-muted',
              )}
            >
              <Icon className="size-4" aria-hidden="true" />
              {label}
            </button>
          ))}
        </div>

        <div className="mt-8 rounded-2xl border border-border bg-card p-6">
          <h2 className="font-heading text-xl font-bold">Qué hace el sistema en esta conversación</h2>
          <p className="mt-1 text-sm text-muted-foreground">Negocio de ejemplo: {active.business}</p>
          <ol className="mt-6 flex flex-col gap-4">
            {active.steps.map((step, i) => (
              <li key={step} className="flex items-start gap-3">
                <span className="flex size-7 shrink-0 items-center justify-center rounded-full bg-accent text-sm font-bold text-accent-foreground">
                  {i + 1}
                </span>
                <span className="pt-0.5 text-sm leading-relaxed">{step}</span>
              </li>
            ))}
          </ol>
        </div>
      </div>

      <div className="lg:w-[340px]">
        <WhatsappDemo
          key={active.id}
          script={active.script}
          contactName={active.business}
          contactInitials={active.initials}
          dayLabel={active.day}
        />
      </div>
    </div>
  )
}
