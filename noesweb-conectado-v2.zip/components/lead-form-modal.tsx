'use client'

import { useEffect, useRef, useState } from 'react'
import { Controller, useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { CheckCircle2, Loader2, X } from 'lucide-react'
import { WHATSAPP_NUMBER } from '@/lib/site'
import { LEAD_PLANS, type LeadOrigen, type LeadPlan } from '@/lib/lead'
import { useMediaQuery } from '@/hooks/use-media-query'
import { cn } from '@/lib/utils'
import { Dialog, DialogClose, DialogContent, DialogDescription, DialogTitle } from '@/components/ui/dialog'
import { Drawer, DrawerClose, DrawerContent, DrawerDescription, DrawerTitle } from '@/components/ui/drawer'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'

export { LEAD_PLANS }
export type { LeadPlan, LeadOrigen }

const leadSchema = z.object({
  nombre: z.string().trim().min(2, 'Ingresá tu nombre'),
  negocio: z.string().trim().min(2, 'Ingresá el nombre de tu negocio'),
  telefono: z
    .string()
    .refine((v) => /^\d{10}$/.test(v.replace(/[\s-]/g, '')), 'Ingresá un teléfono válido de 10 dígitos'),
  plan: z.enum(LEAD_PLANS),
  mensaje: z.string().trim().max(1000, 'Máximo 1000 caracteres'),
  website: z.string(),
})

type LeadValues = z.infer<typeof leadSchema>
type Status = 'idle' | 'success' | 'error'

type LeadFormModalProps = {
  open: boolean
  onOpenChange: (open: boolean) => void
  plan: LeadPlan
  origen: LeadOrigen
}

const TITLE = 'Estás a un paso de automatizar tu negocio'
const DESCRIPTION = 'Completa tus datos y nos pondremos en contacto por WhatsApp.'

const closeButtonClass =
  'absolute right-3 top-3 z-10 inline-flex size-11 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring'

export function LeadFormModal({ open, onOpenChange, plan, origen }: LeadFormModalProps) {
  const isMobile = useMediaQuery('(max-width: 767px)')
  const firstFieldRef = useRef<HTMLInputElement>(null)

  const body = (
    <LeadForm key={`${open}-${plan}`} plan={plan} origen={origen} firstFieldRef={firstFieldRef} onDone={() => onOpenChange(false)} />
  )

  if (isMobile) {
    return (
      <Drawer open={open} onOpenChange={onOpenChange}>
        <DrawerContent
          initialFocus={firstFieldRef}
          className="max-h-[90dvh] rounded-t-3xl data-[swipe-axis=y]:[--drawer-content-max-height:90dvh]"
        >
          <div className="relative flex min-h-0 flex-1 flex-col">
            <DrawerClose className={closeButtonClass} aria-label="Cerrar formulario">
              <X className="size-5" aria-hidden="true" />
            </DrawerClose>
            <div className="px-5 pb-2 pr-16 pt-6">
              <DrawerTitle className="font-heading text-xl font-bold leading-tight text-foreground">{TITLE}</DrawerTitle>
              <DrawerDescription className="mt-1.5 text-sm text-muted-foreground">{DESCRIPTION}</DrawerDescription>
            </div>
            {body}
          </div>
        </DrawerContent>
      </Drawer>
    )
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        showCloseButton={false}
        initialFocus={firstFieldRef}
        className="flex max-h-[90dvh] flex-col gap-0 overflow-hidden rounded-2xl p-0 sm:max-w-md"
      >
        <DialogClose className={closeButtonClass} aria-label="Cerrar formulario">
          <X className="size-5" aria-hidden="true" />
        </DialogClose>
        <div className="px-6 pb-2 pr-16 pt-6">
          <DialogTitle className="font-heading text-xl font-bold leading-tight text-foreground">{TITLE}</DialogTitle>
          <DialogDescription className="mt-1.5 text-sm text-muted-foreground">{DESCRIPTION}</DialogDescription>
        </div>
        {body}
      </DialogContent>
    </Dialog>
  )
}

function LeadForm({
  plan,
  origen,
  firstFieldRef,
  onDone,
}: {
  plan: LeadPlan
  origen: LeadOrigen
  firstFieldRef: React.RefObject<HTMLInputElement | null>
  onDone: () => void
}) {
  const [status, setStatus] = useState<Status>('idle')
  const [fallbackLink, setFallbackLink] = useState('')
  const closeTimer = useRef<ReturnType<typeof setTimeout>>(undefined)

  useEffect(() => () => clearTimeout(closeTimer.current), [])

  const {
    register,
    control,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LeadValues>({
    resolver: zodResolver(leadSchema),
    defaultValues: { nombre: '', negocio: '', telefono: '', plan, mensaje: '', website: '' },
  })

  const { ref: nombreRef, ...nombreField } = register('nombre')

  const scheduleClose = () => {
    setStatus('success')
    closeTimer.current = setTimeout(onDone, 3000)
  }

  const onValid = async (values: LeadValues) => {
    if (values.website) {
      scheduleClose()
      return
    }

    const payload = {
      nombre: values.nombre,
      negocio: values.negocio,
      telefono: `+54${values.telefono.replace(/\D/g, '')}`,
      plan: values.plan,
      mensaje: values.mensaje,
      origen,
    }

    setStatus('idle')
    try {
      const response = await fetch('/api/lead', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      })
      if (!response.ok) throw new Error(`HTTP ${response.status}`)
      scheduleClose()
    } catch {
      const text = `Hola! Soy ${payload.nombre} de ${payload.negocio}. Me interesa el ${payload.plan}.${
        payload.mensaje ? ` ${payload.mensaje}` : ''
      }`
      setFallbackLink(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(text)}`)
      setStatus('error')
    }
  }

  if (status === 'success') {
    return (
      <div
        role="status"
        className="flex flex-col items-center gap-3 px-6 pb-[calc(2.5rem+env(safe-area-inset-bottom))] pt-8 text-center"
      >
        <span className="flex size-14 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
          <CheckCircle2 className="size-8" aria-hidden="true" />
        </span>
        <p className="text-lg font-semibold text-foreground">¡Consulta enviada!</p>
        <p className="text-pretty text-muted-foreground">En breve te escribiremos por WhatsApp.</p>
      </div>
    )
  }

  return (
    <form
      noValidate
      onSubmit={(e) => {
        e.preventDefault()
        void handleSubmit(onValid)(e)
      }}
      className="flex min-h-0 flex-1 flex-col"
    >
      <div className="flex min-h-0 flex-1 flex-col gap-4 overflow-y-auto px-5 py-4 sm:px-6">
        <Field id="lead-nombre" label="Nombre y Apellido" error={errors.nombre?.message}>
          <Input
            id="lead-nombre"
            autoComplete="name"
            aria-invalid={!!errors.nombre}
            aria-describedby={errors.nombre ? 'lead-nombre-error' : undefined}
            className={inputClass}
            {...nombreField}
            ref={(el) => {
              nombreRef(el)
              firstFieldRef.current = el
            }}
          />
        </Field>

        <Field id="lead-negocio" label="Nombre de tu Pyme / Negocio" error={errors.negocio?.message}>
          <Input
            id="lead-negocio"
            autoComplete="organization"
            aria-invalid={!!errors.negocio}
            aria-describedby={errors.negocio ? 'lead-negocio-error' : undefined}
            className={inputClass}
            {...register('negocio')}
          />
        </Field>

        <Field id="lead-telefono" label="Teléfono / WhatsApp" error={errors.telefono?.message}>
          <div className="relative">
            <span
              aria-hidden="true"
              className="pointer-events-none absolute inset-y-1.5 left-0 flex items-center border-r border-input pl-3.5 pr-3 text-base font-medium text-muted-foreground"
            >
              +54
            </span>
            <Input
              id="lead-telefono"
              type="tel"
              inputMode="tel"
              autoComplete="tel-national"
              placeholder="3462 123456"
              aria-label="Teléfono o WhatsApp, código de área y número sin 0 ni 15, prefijo +54"
              aria-invalid={!!errors.telefono}
              aria-describedby={errors.telefono ? 'lead-telefono-error' : 'lead-telefono-hint'}
              className={cn(inputClass, 'pl-[4.5rem]')}
              {...register('telefono')}
            />
          </div>
          {!errors.telefono && (
            <p id="lead-telefono-hint" className="text-xs text-muted-foreground">
              Código de área + número, sin 0 ni 15.
            </p>
          )}
        </Field>

        <Field id="lead-plan" label="Plan de interés" error={errors.plan?.message}>
          <Controller
            control={control}
            name="plan"
            render={({ field }) => (
              <Select value={field.value} onValueChange={(v) => v && field.onChange(v)}>
                <SelectTrigger id="lead-plan" className={cn(inputClass, 'w-full')} aria-label="Plan de interés">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LEAD_PLANS.map((p) => (
                    <SelectItem key={p} value={p} className="py-2.5 text-base">
                      {p}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          />
        </Field>

        <Field id="lead-mensaje" label="¿Qué vendés o qué te gustaría automatizar?" error={errors.mensaje?.message}>
          <Textarea
            id="lead-mensaje"
            rows={3}
            placeholder="Contanos brevemente tu negocio"
            className="min-h-0 rounded-xl px-3.5 py-3 text-base md:text-base"
            {...register('mensaje')}
          />
        </Field>

        <div aria-hidden="true" className="absolute -left-[9999px] h-px w-px overflow-hidden">
          <label htmlFor="lead-website">No completar este campo</label>
          <input id="lead-website" type="text" tabIndex={-1} autoComplete="off" {...register('website')} />
        </div>

        {status === 'error' && (
          <div role="alert" className="flex flex-col gap-3 rounded-xl border border-destructive/30 bg-destructive/5 p-3">
            <p className="text-sm font-medium text-destructive">
              No pudimos enviar tu consulta. Probá de nuevo o escribinos por WhatsApp.
            </p>
            <a
              href={fallbackLink}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex h-11 items-center justify-center rounded-xl border border-border bg-card px-4 text-sm font-semibold transition-colors hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
            >
              Abrir WhatsApp
            </a>
          </div>
        )}
      </div>

      <div className="shrink-0 border-t border-border px-5 pb-[calc(1rem+env(safe-area-inset-bottom))] pt-4 sm:px-6">
        <button
          type="submit"
          disabled={isSubmitting}
          className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-emerald-600 text-base font-semibold text-white shadow-sm transition-colors hover:bg-emerald-700 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-emerald-600 focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-80"
        >
          {isSubmitting ? (
            <>
              <Loader2 className="size-5 animate-spin" aria-hidden="true" />
              Enviando...
            </>
          ) : (
            <>
              <WhatsappIcon className="size-5" />
              Enviar consulta
            </>
          )}
        </button>
      </div>
    </form>
  )
}

const inputClass =
  'h-12 rounded-xl px-3.5 text-base md:text-base focus-visible:ring-2 focus-visible:ring-ring/50 aria-invalid:border-destructive'

function Field({
  id,
  label,
  error,
  children,
}: {
  id: string
  label: string
  error?: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label htmlFor={id} className="text-sm font-medium text-foreground">
        {label}
      </Label>
      {children}
      {error && (
        <p id={`${id}-error`} className="text-sm font-medium text-destructive">
          {error}
        </p>
      )}
    </div>
  )
}

function WhatsappIcon({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true" className={className}>
      <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.79-1.47-1.76-1.65-2.06-.17-.3-.02-.46.13-.6.13-.14.3-.35.45-.52.15-.18.2-.3.3-.5.1-.2.05-.37-.03-.52-.07-.15-.67-1.6-.92-2.2-.24-.58-.49-.5-.67-.5h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.02-1.04 2.48s1.07 2.88 1.21 3.08c.15.2 2.1 3.2 5.08 4.48.71.31 1.26.49 1.7.63.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.7.25-1.29.17-1.41-.07-.13-.27-.2-.57-.35M12.05 21.5h-.01a9.4 9.4 0 0 1-4.8-1.32l-.34-.2-3.57.94.95-3.48-.22-.36a9.4 9.4 0 0 1-1.44-5.02c0-5.2 4.23-9.43 9.44-9.43 2.52 0 4.89.98 6.67 2.77a9.37 9.37 0 0 1 2.76 6.67c0 5.2-4.24 9.43-9.44 9.43m8.03-17.46A11.3 11.3 0 0 0 12.04.72C5.79.72.7 5.8.7 12.07c0 2 .52 3.95 1.52 5.67L.6 23.62l6.01-1.58a11.3 11.3 0 0 0 5.43 1.38h.01c6.25 0 11.34-5.09 11.34-11.35 0-3.03-1.18-5.88-3.32-8.02" />
    </svg>
  )
}
