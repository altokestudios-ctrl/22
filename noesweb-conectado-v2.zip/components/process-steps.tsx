import { Reveal } from '@/components/reveal'
import { cn } from '@/lib/utils'

const steps = [
  {
    number: '01',
    title: 'Nos contás sobre tu negocio',
    text: 'Analizamos tu catálogo, precios y forma de atender clientes para diseñar el flujo ideal de conversación.',
  },
  {
    number: '02',
    title: 'Configuramos tu asistente IA',
    text: 'Entrenamos al asistente con tus productos, precios y preguntas frecuentes. Si tu plan lo incluye, conectamos tu catálogo y stock.',
  },
  {
    number: '03',
    title: 'Tu asistente atiende por vos',
    text: 'Lo activamos en tu WhatsApp y vos recibís las consultas y los pedidos ya ordenados.',
  },
]

export function ProcessSteps() {
  return (
    <section aria-labelledby="proceso" className="py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Proceso</p>
          <h2 id="proceso" className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Así de simple es automatizar tu negocio
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Así trabajamos, en 3 pasos.
          </p>
        </Reveal>

        <ol className="mt-14 grid gap-6 md:grid-cols-3 md:gap-8">
          {steps.map((step, i) => (
            <li key={step.number} className="relative">
              {i < steps.length - 1 && (
                <span
                  aria-hidden="true"
                  className="absolute left-[calc(50%+2.5rem)] right-[calc(-50%+2.5rem)] top-[3.25rem] hidden border-t-2 border-dashed border-primary/30 md:block"
                />
              )}
              <Reveal delay={i * 120} className="h-full">
                <article className="relative flex h-full flex-col items-center rounded-2xl border border-border bg-card p-7 text-center shadow-sm transition-all duration-300 hover:scale-[1.02] hover:shadow-lg">
                  <span
                    className={cn(
                      'flex size-14 items-center justify-center rounded-2xl bg-accent font-heading text-2xl font-bold text-accent-foreground',
                    )}
                  >
                    {step.number}
                  </span>
                  <h3 className="mt-5 text-lg font-semibold">{step.title}</h3>
                  <p className="mt-2 text-pretty leading-relaxed text-muted-foreground">{step.text}</p>
                </article>
              </Reveal>
            </li>
          ))}
        </ol>
      </div>
    </section>
  )
}
