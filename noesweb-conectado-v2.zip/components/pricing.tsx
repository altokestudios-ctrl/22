import { Check, Wrench, RefreshCw } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Reveal } from '@/components/reveal'
import { LeadFormTrigger } from '@/components/lead-form-provider'
import type { LeadOrigen, LeadPlan } from '@/components/lead-form-modal'

const plans: {
  name: LeadPlan
  origen: LeadOrigen
  description: string
  features: string[]
  featured: boolean
}[] = [
  {
    name: 'Plan Inicio',
    origen: 'plan-inicio',
    description: 'Para negocios que quieren dejar de perder consultas fuera de horario.',
    features: [
      'Asistente de ventas por WhatsApp',
      'Entrenamiento con tus productos y preguntas frecuentes',
      'Derivación a un humano cuando hace falta',
      'Reporte mensual de conversaciones',
    ],
    featured: false,
  },
  {
    name: 'Plan Crecimiento',
    origen: 'plan-crecimiento',
    description: 'Para negocios con catálogo amplio que quieren informar precio y stock de forma automática.',
    features: [
      'Todo lo del Plan Inicio',
      'Integración con Catálogo / Base de Datos',
      'Stock y precios desde tu catálogo',
      'Links de pago automáticos',
      'Soporte prioritario',
    ],
    featured: true,
  },
]

export function Pricing() {
  return (
    <section id="planes" className="scroll-mt-16 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Planes</p>
          <h2 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Planes con presupuesto a medida
          </h2>
          <p className="mt-4 text-pretty text-lg text-muted-foreground">
            Cada negocio es distinto. Te pasamos un presupuesto con el detalle de qué incluye el setup y el abono mensual.
          </p>
        </Reveal>

        <div className="mx-auto mt-12 grid max-w-4xl gap-4 sm:grid-cols-2">
          <div className="flex gap-4 rounded-2xl border border-border bg-card p-5">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <Wrench className="size-5" aria-hidden="true" />
            </span>
            <div>
              <p className="font-semibold">Setup inicial · pago único</p>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                Implementación, diseño del flujo de conversación y entrenamiento a medida de tu negocio.
              </p>
            </div>
          </div>
          <div className="flex gap-4 rounded-2xl border border-border bg-card p-5">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-accent text-accent-foreground">
              <RefreshCw className="size-5" aria-hidden="true" />
            </span>
            <div>
              <p className="font-semibold">Abono mensual</p>
              <p className="mt-1 text-sm leading-relaxed text-muted-foreground">
                Mantenimiento de servidores, créditos de IA, mejoras continuas y soporte técnico.
              </p>
            </div>
          </div>
        </div>

        <div className="mx-auto mt-8 grid max-w-4xl gap-6 md:grid-cols-2">
          {plans.map((plan) => (
            <article
              key={plan.name}
              className={cn(
                'relative flex flex-col rounded-2xl border p-8 transition-all duration-300 hover:scale-[1.02] hover:shadow-xl',
                plan.featured
                  ? 'border-primary bg-card shadow-xl shadow-primary/10 ring-1 ring-primary'
                  : 'border-border bg-card shadow-sm',
              )}
            >
              {plan.featured && (
                <span className="absolute -top-3 right-8 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Más completo
                </span>
              )}
              <h3 className="text-2xl font-bold">{plan.name}</h3>
              <p className="mt-2 text-muted-foreground">{plan.description}</p>

              <dl className="mt-6 grid grid-cols-2 gap-3 rounded-xl bg-muted p-4 text-sm">
                <div>
                  <dt className="text-muted-foreground">Setup</dt>
                  <dd className="font-semibold">Pago único</dd>
                </div>
                <div>
                  <dt className="text-muted-foreground">Mantenimiento</dt>
                  <dd className="font-semibold">Abono mensual</dd>
                </div>
              </dl>

              <ul className="mt-6 flex flex-1 flex-col gap-3">
                {plan.features.map((f) => (
                  <li key={f} className="flex items-start gap-2.5 text-sm">
                    <Check className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden="true" />
                    {f}
                  </li>
                ))}
              </ul>

              <LeadFormTrigger
                plan={plan.name}
                origen={plan.origen}
                className={cn(
                  'mt-8 inline-flex items-center justify-center rounded-xl px-5 py-3 text-sm font-semibold transition-colors',
                  plan.featured
                    ? 'bg-primary text-primary-foreground shadow-lg shadow-primary/25 hover:bg-primary/90'
                    : 'border border-border bg-card hover:bg-muted',
                )}
              >
                Consultar Presupuesto a Medida
              </LeadFormTrigger>
            </article>
          ))}
        </div>
      </div>
    </section>
  )
}
