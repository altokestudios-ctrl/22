import { cn } from '@/lib/utils'

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" aria-hidden="true" className={cn('size-8 shrink-0', className)}>
      <rect width="32" height="32" rx="9" className="fill-foreground" />
      <path
        d="M9.5 23.5 16 8.5l6.5 15"
        fill="none"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="stroke-background"
      />
      <circle cx="16" cy="19" r="2" className="fill-primary" />
      <circle cx="24.5" cy="8" r="2.25" className="fill-primary" />
    </svg>
  )
}

export function BrandLogo({ className }: { className?: string }) {
  return (
    <span className={cn('flex items-center gap-2.5 font-heading text-lg tracking-tight', className)}>
      <BrandMark />
      <span className="leading-none">
        <span className="font-extrabold">Altoke</span> <span className="font-semibold text-muted-foreground">Studio</span>
      </span>
    </span>
  )
}
