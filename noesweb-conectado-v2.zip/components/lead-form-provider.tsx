'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { LeadFormModal, type LeadOrigen, type LeadPlan } from '@/components/lead-form-modal'

type OpenLeadForm = (options: { plan: LeadPlan; origen: LeadOrigen }) => void

const LeadFormContext = createContext<OpenLeadForm | null>(null)

export function LeadFormProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false)
  const [plan, setPlan] = useState<LeadPlan>('No estoy seguro, necesito asesoramiento')
  const [origen, setOrigen] = useState<LeadOrigen>('hero')

  const openLeadForm = useCallback<OpenLeadForm>((options) => {
    setPlan(options.plan)
    setOrigen(options.origen)
    setOpen(true)
  }, [])

  const value = useMemo(() => openLeadForm, [openLeadForm])

  return (
    <LeadFormContext.Provider value={value}>
      {children}
      <LeadFormModal open={open} onOpenChange={setOpen} plan={plan} origen={origen} />
    </LeadFormContext.Provider>
  )
}

export function LeadFormTrigger({
  plan,
  origen,
  className,
  children,
}: {
  plan: LeadPlan
  origen: LeadOrigen
  className?: string
  children: React.ReactNode
}) {
  const openLeadForm = useContext(LeadFormContext)
  if (!openLeadForm) throw new Error('LeadFormTrigger must be used within LeadFormProvider')

  return (
    <button type="button" onClick={() => openLeadForm({ plan, origen })} className={className}>
      {children}
    </button>
  )
}
