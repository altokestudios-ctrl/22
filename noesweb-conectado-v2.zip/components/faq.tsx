import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion'
import { Reveal } from '@/components/reveal'

const faqs = [
  {
    q: '¿Necesito conocimientos técnicos?',
    a: 'No. Nosotros nos encargamos de la configuración. Vos nos pasás tu catálogo y respondés unas preguntas sobre tu negocio.',
  },
  {
    q: '¿Funciona con mi número de WhatsApp actual?',
    a: 'Depende de cómo tengas configurado tu WhatsApp. Lo revisamos cuando armamos el presupuesto y te decimos qué opción conviene en tu caso.',
  },
  {
    q: '¿Qué pasa si el bot no sabe responder algo?',
    a: 'Deriva la conversación a vos o a tu equipo, que pueden ver el chat completo y continuar la atención.',
  },
  {
    q: '¿Cuánto tarda la implementación?',
    a: 'Depende del tamaño de tu catálogo y de las integraciones que necesites. Te lo informamos en el presupuesto, antes de empezar.',
  },
  {
    q: '¿Puedo cancelar cuando quiera?',
    a: 'Las condiciones del abono mensual y cómo darlo de baja se detallan por escrito en el presupuesto, antes de contratar.',
  },
  {
    q: '¿Qué medios de pago aceptan?',
    a: 'Los medios de pago se acuerdan en el presupuesto.',
  },
]

export function Faq() {
  return (
    <section id="faq" aria-labelledby="faq-title" className="scroll-mt-16 border-t border-border bg-card py-20 lg:py-28">
      <div className="mx-auto max-w-3xl px-4 sm:px-6">
        <Reveal className="text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Preguntas frecuentes</p>
          <h2 id="faq-title" className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            ¿Tenés dudas? Acá las resolvemos
          </h2>
        </Reveal>

        <Reveal className="mt-12">
          <Accordion className="gap-3">
            {faqs.map((item) => (
              <AccordionItem
                key={item.q}
                value={item.q}
                className="rounded-2xl border border-border bg-background px-5 transition-shadow not-last:border-b hover:shadow-sm"
              >
                <AccordionTrigger className="py-5 text-base font-semibold hover:no-underline">{item.q}</AccordionTrigger>
                <AccordionContent className="pb-5 text-base leading-relaxed text-muted-foreground">
                  {item.a}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </div>
    </section>
  )
}
