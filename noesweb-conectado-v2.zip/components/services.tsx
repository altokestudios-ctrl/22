import { Boxes, Check, Headset, TrendingUp } from 'lucide-react'
import { cn } from '@/lib/utils'
import { Reveal } from '@/components/reveal'

const services = [
  {
    icon: TrendingUp,
    title: 'IA de Ventas y Captación de Leads',
    text: 'Califica a cada cliente, responde consultas, cotiza y lo lleva hasta el link de pago sin que levantes el teléfono.',
    features: ['Cotizaciones automáticas', 'Link de pago en la conversación', 'Derivación a una persona cuando hace falta'],
    featured: true,
  },
  {
    icon: Headset,
    title: 'IA de Soporte y Atención al Cliente',
    text: 'Resuelve preguntas frecuentes, horarios, envíos y garantías. Si hace falta un humano, te deriva la charla.',
    features: ['Respuestas con el tono de tu marca', 'Derivación a tu equipo', 'Disponible a toda hora'],
    featured: false,
  },
  {
    icon: Boxes,
    title: 'Integración de Catálogo y Stock',
    text: 'Conectamos tu planilla, sistema de gestión o catálogo para que el bot siempre informe precio y disponibilidad real.',
    features: ['Google Sheets o Excel', 'Precios y stock desde tu catálogo', 'Configuración a medida'],
    featured: false,
  },
]

export function Services() {
  return (
    <section id="servicios" className="scroll-mt-16 py-20 lg:py-28">
      <div className="mx-auto max-w-6xl px-4 sm:px-6">
        <Reveal className="mx-auto max-w-2xl text-center">
          <p className="text-sm font-semibold uppercase tracking-wider text-primary">Servicios</p>
          <h2 className="mt-3 text-balance text-3xl font-bold tracking-tight sm:text-4xl">
            Asistentes que trabajan a toda hora, hechos a medida de tu negocio
          </h2>
        </Reveal>

        <div className="mt-14 grid gap-6 md:grid-cols-3">
          {services.map(({ icon: Icon, title, text, features, featured }, i) => (
            <Reveal key={title} delay={i * 120} className="h-full">
            <article
              className={cn(
                'relative flex h-full flex-col rounded-2xl border p-7 transition-all duration-300 hover:scale-[1.02] hover:shadow-xl',
                featured ? 'border-primary bg-card shadow-lg shadow-primary/10' : 'border-border bg-card shadow-sm',
              )}
            >
              {featured && (
                <span className="absolute -top-3 left-7 rounded-full bg-primary px-3 py-1 text-xs font-semibold text-primary-foreground">
                  Servicio Estrella
                </span>
              )}
              <span
                className={cn(
                  'flex size-12 items-center justify-center rounded-xl',
                  featured ? 'bg-primary text-primary-foreground' : 'bg-accent text-accent-foreground',
                )}
              >
                <Icon className="size-6" aria-hidden="true" />
              </span>
              <h3 className="mt-6 text-xl font-bold leading-snug">{title}</h3>
              <p className="mt-3 leading-relaxed text-muted-foreground">{text}</p>
              <ul className="mt-6 flex flex-col gap-2.5 border-t border-border pt-6">
                {features.map((f) => (
                  <li key={f} className="flex items-center gap-2 text-sm">
                    <Check className="size-4 shrink-0 text-primary" aria-hidden="true" />
                    {f}
                  </li>
                ))}
              </ul>
            </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  )
}
